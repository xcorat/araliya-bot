//! # Hex Button — GPUI Transparent Hexagon with Toggle Window
//!
//! Renders a **borderless, transparent hexagon** using GPUI's `canvas` element.
//! Inside the hexagon sits a small circular icon button that opens / closes a
//! secondary rectangular panel window.
//!
//! ## Key GPUI concepts used
//! - `canvas(paint_fn)` — low-level 2-D drawing via `gpui::Scene` path APIs
//! - `WindowOptions` with `titlebar: None` + `is_movable: true` for a chrome-free window
//! - `gpui::Model<AppState>` — shared reactive state between two windows
//! - `cx.open_window` / `cx.update_window` — multi-window management
//!
//! ## Running
//! ```sh
//! cargo run
//! ```
//!
//! ## Notes on Cargo.toml
//! GPUI is not yet published to crates.io independently.  Point the dependency
//! at the `gpui` crate inside a local Zed checkout:
//! ```toml
//! [dependencies]
//! gpui = { path = "../zed/crates/gpui" }
//! ```

use gpui::{
    canvas, div, point, px, rgb, size, App, AppContext, Bounds, Canvas, ClickEvent, Context,
    Element, ElementId, EventEmitter, FocusHandle, FocusableView, Hsla, IntoElement, Model,
    MouseButton, MouseDownEvent, ParentElement as _, Path, Pixels, Point, Render, Rgba,
    SharedString, Styled, Task, View, ViewContext, VisualContext, WindowHandle, WindowOptions,
};

// ─────────────────────────────────────────────
// Shared application state
// ─────────────────────────────────────────────

/// Shared state that both windows react to.
#[derive(Debug)]
struct AppState {
    /// Is the secondary panel currently visible?
    panel_open: bool,
    /// Handle to the panel window so we can close it programmatically.
    panel_handle: Option<WindowHandle<PanelView>>,
}

impl AppState {
    fn new() -> Self {
        Self {
            panel_open: false,
            panel_handle: None,
        }
    }
}

// GPUI requires an `EventEmitter` impl even if we emit nothing.
impl EventEmitter<()> for AppState {}

// ─────────────────────────────────────────────
// Hexagon view (primary window)
// ─────────────────────────────────────────────

/// The root view rendered inside the transparent hexagon window.
struct HexView {
    state: Model<AppState>,
    focus_handle: FocusHandle,
}

impl FocusableView for HexView {
    fn focus_handle(&self, _cx: &AppContext) -> FocusHandle {
        self.focus_handle.clone()
    }
}

impl HexView {
    fn new(state: Model<AppState>, cx: &mut ViewContext<Self>) -> Self {
        Self {
            state,
            focus_handle: cx.focus_handle(),
        }
    }

    /// Toggle the panel: open it if closed, close it if open.
    fn toggle_panel(&mut self, _: &ClickEvent, cx: &mut ViewContext<Self>) {
        let is_open = self.state.read(cx).panel_open;
        if is_open {
            // Close the panel window.
            self.state.update(cx, |state, _| {
                if let Some(handle) = state.panel_handle.take() {
                    // `WindowHandle::close` schedules window removal.
                    drop(handle); // dropping removes the strong ref; GPUI GCs it
                }
                state.panel_open = false;
            });
        } else {
            // Open a new panel window.
            let state_clone = self.state.clone();
            let panel_handle = cx.open_window(panel_window_options(), |cx| {
                cx.new_view(|cx| PanelView::new(state_clone.clone(), cx))
            });
            if let Ok(handle) = panel_handle {
                self.state.update(cx, |state, _| {
                    state.panel_handle = Some(handle);
                    state.panel_open = true;
                });
            }
        }
    }
}

impl Render for HexView {
    fn render(&mut self, cx: &mut ViewContext<Self>) -> impl IntoElement {
        let is_open = self.state.read(cx).panel_open;
        // Clone what we need for the canvas closure (must be 'static).
        let is_open_for_canvas = is_open;

        // The canvas element is sized to the hexagon bounding box.
        // HEX_SIZE is the circumradius (centre → vertex).
        const HEX_SIZE: f32 = 120.0;
        let canvas_side = HEX_SIZE * 2.0 + 4.0; // small margin for AA

        div()
            .size(px(canvas_side))
            // No background — the OS compositor will show transparency where
            // we don't paint (requires the window to be transparent, see main).
            .child(
                canvas(
                    // `before_layout` — nothing needed here
                    |_, _| {},
                    // `paint` — draw hexagon + icon every frame
                    move |bounds, _, cx| {
                        paint_hex_scene(bounds, HEX_SIZE, is_open_for_canvas, cx);
                    },
                )
                .size_full(),
            )
            // Intercept left-click anywhere on the element to toggle the panel.
            // In production you'd hit-test only the icon circle; for brevity we
            // catch the whole canvas region.
            .on_click(cx.listener(Self::toggle_panel))
    }
}

// ─────────────────────────────────────────────
// Canvas painting helpers
// ─────────────────────────────────────────────

/// Compute the six vertices of a flat-top regular hexagon.
///
/// `cx`, `cy` — centre in window-local pixels  
/// `r`        — circumradius (centre → vertex)
fn hex_vertices(cx: f32, cy: f32, r: f32) -> [Point<Pixels>; 6] {
    std::array::from_fn(|i| {
        // Flat-top orientation: first vertex at 0° (right).
        let angle = std::f32::consts::FRAC_PI_3 * i as f32;
        point(px(cx + r * angle.cos()), px(cy + r * angle.sin()))
    })
}

/// Paint the hexagon body, outline, and the toggle-button icon.
///
/// Called each frame inside GPUI's `canvas` paint callback.
fn paint_hex_scene(bounds: Bounds<Pixels>, r: f32, panel_open: bool, cx: &mut gpui::WindowContext) {
    let cx_pos = bounds.center().x.0;
    let cy_pos = bounds.center().y.0;

    // ── Hexagon fill ──────────────────────────────────────────────────────────
    let verts = hex_vertices(cx_pos, cy_pos, r);
    let mut hex_path = Path::new(verts[0]);
    for v in &verts[1..] {
        hex_path.line_to(*v);
    }
    hex_path.close();

    // Deep blue-grey fill, slight transparency.
    cx.paint_path(hex_path.clone(), Rgba { r: 0.10, g: 0.13, b: 0.20, a: 0.92 }.into());

    // ── Hexagon outline ───────────────────────────────────────────────────────
    // GPUI path stroke isn't a single call — approximate with a wider path or
    // draw each edge as a thin quad.  For simplicity, paint a slightly larger
    // hex below the fill (painter's algorithm).
    let verts_outer = hex_vertices(cx_pos, cy_pos, r + 2.5);
    let mut outline_path = Path::new(verts_outer[0]);
    for v in &verts_outer[1..] {
        outline_path.line_to(*v);
    }
    outline_path.close();
    cx.paint_path(outline_path, Rgba { r: 0.45, g: 0.70, b: 1.0, a: 0.85 }.into());
    // Re-paint interior so the outline is only a border ring.
    cx.paint_path(hex_path, Rgba { r: 0.10, g: 0.13, b: 0.20, a: 0.92 }.into());

    // ── Toggle icon (circle with ± symbol) ────────────────────────────────────
    // Draw a small circle in the hex centre.
    const ICON_R: f32 = 20.0;
    let icon_color: Rgba = if panel_open {
        Rgba { r: 0.95, g: 0.35, b: 0.35, a: 1.0 } // red  → means "close"
    } else {
        Rgba { r: 0.35, g: 0.85, b: 0.55, a: 1.0 } // green → means "open"
    };

    // Approximate circle with a 32-segment polygon.
    let icon_verts: Vec<Point<Pixels>> = (0..32)
        .map(|i| {
            let a = std::f32::consts::TAU / 32.0 * i as f32;
            point(
                px(cx_pos + ICON_R * a.cos()),
                px(cy_pos + ICON_R * a.sin()),
            )
        })
        .collect();

    let mut circle_path = Path::new(icon_verts[0]);
    for v in &icon_verts[1..] {
        circle_path.line_to(*v);
    }
    circle_path.close();
    cx.paint_path(circle_path, icon_color.into());

    // ── "+" / "×" strokes inside the icon ─────────────────────────────────────
    // Render as thin rectangles (horizontal + vertical bars).
    let bar_half = ICON_R * 0.45;
    let bar_thick = 3.5_f32;

    if panel_open {
        // "×" — two diagonal bars at ±45°.
        for sign in [-1.0_f32, 1.0] {
            let diag: Vec<Point<Pixels>> = [
                (-bar_half, -bar_half * sign),
                (bar_half, bar_half * sign),
                (bar_half + bar_thick * 0.5, bar_half * sign - bar_thick * 0.5),
                (-bar_half + bar_thick * 0.5, -bar_half * sign - bar_thick * 0.5),
            ]
            .iter()
            .map(|(dx, dy)| point(px(cx_pos + dx), px(cy_pos + dy)))
            .collect();
            let mut p = Path::new(diag[0]);
            for v in &diag[1..] {
                p.line_to(*v);
            }
            p.close();
            cx.paint_path(p, Rgba { r: 1.0, g: 1.0, b: 1.0, a: 0.9 }.into());
        }
    } else {
        // "+" — horizontal bar.
        let h_bar = [
            point(px(cx_pos - bar_half), px(cy_pos - bar_thick / 2.0)),
            point(px(cx_pos + bar_half), px(cy_pos - bar_thick / 2.0)),
            point(px(cx_pos + bar_half), px(cy_pos + bar_thick / 2.0)),
            point(px(cx_pos - bar_half), px(cy_pos + bar_thick / 2.0)),
        ];
        let mut p = Path::new(h_bar[0]);
        for v in &h_bar[1..] { p.line_to(*v); }
        p.close();
        cx.paint_path(p, Rgba { r: 1.0, g: 1.0, b: 1.0, a: 0.9 }.into());

        // Vertical bar.
        let v_bar = [
            point(px(cx_pos - bar_thick / 2.0), px(cy_pos - bar_half)),
            point(px(cx_pos + bar_thick / 2.0), px(cy_pos - bar_half)),
            point(px(cx_pos + bar_thick / 2.0), px(cy_pos + bar_half)),
            point(px(cx_pos - bar_thick / 2.0), px(cy_pos + bar_half)),
        ];
        let mut p = Path::new(v_bar[0]);
        for v in &v_bar[1..] { p.line_to(*v); }
        p.close();
        cx.paint_path(p, Rgba { r: 1.0, g: 1.0, b: 1.0, a: 0.9 }.into());
    }
}

// ─────────────────────────────────────────────
// Panel view (secondary window)
// ─────────────────────────────────────────────

/// A simple rectangular panel opened by clicking the hexagon icon.
struct PanelView {
    state: Model<AppState>,
    focus_handle: FocusHandle,
}

impl FocusableView for PanelView {
    fn focus_handle(&self, _cx: &AppContext) -> FocusHandle {
        self.focus_handle.clone()
    }
}

impl PanelView {
    fn new(state: Model<AppState>, cx: &mut ViewContext<Self>) -> Self {
        Self {
            state,
            focus_handle: cx.focus_handle(),
        }
    }
}

impl Render for PanelView {
    fn render(&mut self, _cx: &mut ViewContext<Self>) -> impl IntoElement {
        div()
            .size_full()
            .bg(rgb(0x1a2030))
            .flex()
            .flex_col()
            .items_center()
            .justify_center()
            .gap(px(12.0))
            .child(
                div()
                    .text_color(rgb(0xadd8ff))
                    .child("Hello from the panel!"),
            )
            .child(
                div()
                    .text_color(rgb(0x88aacc))
                    .child("Click the hexagon icon to close."),
            )
    }
}

// ─────────────────────────────────────────────
// Window option helpers
// ─────────────────────────────────────────────

/// Options for the primary transparent hexagon window.
fn hex_window_options() -> WindowOptions {
    let side = 248.0_f32; // bounding box for the hexagon
    WindowOptions {
        // No title bar — just the raw content.
        titlebar: None,
        // Transparent OS window (compositor blending).
        is_transparent: true,
        // Allow the user to drag the window by clicking its background.
        focus: true,
        show: true,
        bounds: Some(gpui::WindowBounds::Fixed(gpui::Bounds {
            origin: point(px(100.0), px(100.0)),
            size: size(px(side), px(side)),
        })),
        ..Default::default()
    }
}

/// Options for the secondary panel window.
fn panel_window_options() -> WindowOptions {
    WindowOptions {
        titlebar: Some(gpui::TitlebarOptions {
            title: Some(SharedString::from("Panel")),
            appears_transparent: false,
            traffic_light_position: None,
        }),
        focus: true,
        show: true,
        bounds: Some(gpui::WindowBounds::Fixed(gpui::Bounds {
            origin: point(px(380.0), px(100.0)),
            size: size(px(280.0), px(180.0)),
        })),
        ..Default::default()
    }
}

// ─────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────

fn main() {
    // `App::new()` boots the GPUI event loop.
    App::new().run(|cx: &mut AppContext| {
        // Shared reactive state (wrapped in a GPUI Model for change tracking).
        let state = cx.new_model(|_| AppState::new());

        // Open the primary hexagon window.
        cx.open_window(hex_window_options(), |cx| {
            cx.new_view(|cx| HexView::new(state.clone(), cx))
        })
        .expect("Failed to open hexagon window");
    });
}

// ─────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use gpui::TestAppContext;

    /// Verify the six hexagon vertices form a convex polygon whose
    /// centroid is the expected centre point.
    #[test]
    fn hex_vertices_centroid() {
        let (cx, cy, r) = (100.0, 100.0, 50.0);
        let verts = hex_vertices(cx, cy, r);
        assert_eq!(verts.len(), 6);

        let sum_x: f32 = verts.iter().map(|v| v.x.0).sum();
        let sum_y: f32 = verts.iter().map(|v| v.y.0).sum();
        let centroid_x = sum_x / 6.0;
        let centroid_y = sum_y / 6.0;

        // Centroid should equal the provided centre within floating-point error.
        assert!((centroid_x - cx).abs() < 1e-4, "centroid_x={centroid_x}");
        assert!((centroid_y - cy).abs() < 1e-4, "centroid_y={centroid_y}");
    }

    /// All vertices should be exactly `r` pixels from the centre.
    #[test]
    fn hex_vertices_equidistant() {
        let (cx, cy, r) = (0.0, 0.0, 80.0);
        let verts = hex_vertices(cx, cy, r);
        for v in &verts {
            let dist = ((v.x.0 - cx).powi(2) + (v.y.0 - cy).powi(2)).sqrt();
            assert!(
                (dist - r).abs() < 1e-4,
                "vertex distance {dist} != r {r}"
            );
        }
    }

    /// Consecutive vertex angles should be 60° apart (flat-top orientation).
    #[test]
    fn hex_vertices_angles() {
        let verts = hex_vertices(0.0, 0.0, 100.0);
        for i in 0..6 {
            let j = (i + 1) % 6;
            let a1 = verts[i].y.0.atan2(verts[i].x.0);
            let a2 = verts[j].y.0.atan2(verts[j].x.0);
            let mut diff = (a2 - a1).to_degrees();
            if diff < 0.0 { diff += 360.0; }
            assert!(
                (diff - 60.0).abs() < 1e-3,
                "angle diff between vertex {i} and {j} is {diff}°, expected 60°"
            );
        }
    }

    /// `AppState` starts closed with no panel handle.
    #[test]
    fn app_state_defaults() {
        let state = AppState::new();
        assert!(!state.panel_open);
        assert!(state.panel_handle.is_none());
    }

    /// Toggle logic: flipping `panel_open` back and forth.
    #[test]
    fn app_state_toggle_logic() {
        let mut state = AppState::new();
        state.panel_open = true;
        assert!(state.panel_open);
        state.panel_open = false;
        assert!(!state.panel_open);
    }

    // ── GPUI integration tests ────────────────────────────────────────────────

    /// Verify that `HexView` renders without panicking inside a test context.
    #[gpui::test]
    fn hex_view_renders(cx: &mut TestAppContext) {
        let state = cx.new_model(|_| AppState::new());
        let view = cx.add_window(|cx| HexView::new(state, cx));
        // Just asserting we can read back the view without error.
        view.read_with(cx, |v, _cx| {
            assert!(!v.state.read(_cx).panel_open);
        });
    }

    /// Verify that `PanelView` renders without panicking.
    #[gpui::test]
    fn panel_view_renders(cx: &mut TestAppContext) {
        let state = cx.new_model(|_| AppState::new());
        let view = cx.add_window(|cx| PanelView::new(state, cx));
        view.read_with(cx, |_, _| {});
    }
}
