# hex_button

A minimal GPUI application that renders a **transparent, borderless hexagon window**.
Inside the hexagon is a circular icon button (green `+` / red `×`) that opens and
closes a secondary rectangular panel window.

```
┌─────────────────────────────┐
│  Transparent OS window      │
│                             │
│       ⬡ hexagon             │
│        ⊕ icon button        │
│                             │
└─────────────────────────────┘
         ↓ click
┌─────────┐
│  Panel  │  (normal window, toggled by the icon)
└─────────┘
```

## Dependencies

GPUI is the GPU-accelerated UI framework from the [Zed](https://github.com/zed-industries/zed)
editor.  It is not yet independently published to crates.io, so you must point `Cargo.toml` at
a local clone:

```toml
[dependencies]
gpui = { path = "../zed/crates/gpui" }
```

Clone Zed alongside this repo:

```sh
git clone https://github.com/zed-industries/zed ../zed
```

Then build/run as normal:

```sh
cargo run
cargo test
```

## Architecture

| File | Purpose |
|------|---------|
| `src/main.rs` | Everything — state, views, canvas painting, tests |

### Key types

- **`AppState`** — `gpui::Model` holding `panel_open: bool` and the panel `WindowHandle`.
- **`HexView`** — Primary view; draws via `canvas(paint_fn)`, handles click to toggle.
- **`PanelView`** — Secondary view; plain `div`-based layout, standard window chrome.
- **`paint_hex_scene`** — Pure function; renders hexagon + outline + circular icon using
  `Path` + `cx.paint_path`.

### Canvas drawing approach

GPUI's `canvas` element exposes a `paint` callback receiving `Bounds<Pixels>` and a
`&mut WindowContext`.  Paths are built with `gpui::Path::new(start)` → `.line_to()` →
`.close()` and submitted with `cx.paint_path(path, color)`.  No retained scene objects —
everything is repainted each frame.

## Tests

Unit tests (no GPU required):

- `hex_vertices_centroid` — centroid of the 6 vertices equals the input centre.
- `hex_vertices_equidistant` — all vertices are exactly `r` px from centre.
- `hex_vertices_angles` — consecutive vertices are 60° apart.
- `app_state_defaults` — `AppState::new()` is closed with no handle.
- `app_state_toggle_logic` — boolean flipping works correctly.

GPUI integration tests (`#[gpui::test]`):

- `hex_view_renders` — `HexView` constructs without panicking.
- `panel_view_renders` — `PanelView` constructs without panicking.
